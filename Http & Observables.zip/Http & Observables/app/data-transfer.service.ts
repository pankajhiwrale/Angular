import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IBatch } from 'src/batches';

@Injectable({
  providedIn: 'root'
})
export class DataTransferService {

  public _url = "assets/Data/batches.json";

  constructor(private hobj : HttpClient) { }



  public getBatchDetails():Observable<IBatch[]>
  {
    return this.hobj.get<IBatch[]>(this._url);
  }


}
