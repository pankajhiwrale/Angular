import { Component } from '@angular/core';
import { DataTransferService } from '../data-transfer.service';

@Component({
  selector: 'app-batch-list',
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.css']
})
export class BatchListComponent {

  public batch:any[] = [];

  constructor(public obj: DataTransferService){}

  ngOnInit(){
    this.obj.getBatchDetails().subscribe(data=>this.batch = data);
  }




}
