export interface IBatch
{
    Name : string,
    EmployeeID : number,
    Location : string
}