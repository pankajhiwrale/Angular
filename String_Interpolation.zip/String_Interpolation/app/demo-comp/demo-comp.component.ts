import { Component } from '@angular/core';

@Component({
  selector: 'app-demo-comp',
  templateUrl: './demo-comp.component.html',
  styleUrls: ['./demo-comp.component.css']
})
export class DemoCompComponent {

  public name:string =  'Pankaj';  //this data will be going to talk with html

}
