import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Project';

//ng-if directive

public flag = true;

//ng-for directive

sar = [];
sname:string = "";

AddStudent()
{
  this.sar.push(this.sname);
}





}
