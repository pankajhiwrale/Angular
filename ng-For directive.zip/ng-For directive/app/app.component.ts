import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Project';

  
  Arr:string[] = [];

  InputVar:string = "";


  AddSomethingInsideArray()
  {
    this.Arr.push(this.InputVar);
  }




}
