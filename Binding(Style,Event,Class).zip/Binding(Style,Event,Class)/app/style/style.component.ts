import { Component } from '@angular/core';

@Component({
  selector: 'app-style',
  templateUrl: './style.component.html',
  styleUrls: ['./style.component.css']
})
export class StyleComponent {



public Mycolor = "orange";   //variable that we are using to display inside html

public Isset = false;  //to achieve conditional styling in html







}
