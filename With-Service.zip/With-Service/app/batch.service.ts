import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class BatchService {

  constructor() { }

  public getBatchDetails()
  {
    
    return [
      {"Name" : "Pankaj", "Subject" : "Science", "Marks" : 100},
      {"Name" : "Amit", "Subject" : "English", "Marks" : 200}
    ];
  }

}  
