import { Component, OnInit} from '@angular/core';
import { BatchService } from '../batch.service';

@Component({
  selector: 'app-batch-detail',
  templateUrl: './batch-detail.component.html',
  styleUrls: ['./batch-detail.component.css']
})
export class BatchDetailComponent implements OnInit{

  public Batches: any[] = [];

  constructor(private obj: BatchService)
  {
    
  }

  ngOnInit(): void{

    this.Batches = this.obj.getBatchDetails();
    
  }

}
