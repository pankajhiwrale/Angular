import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BatchListComponent } from './batch-list/batch-list.component';
import { BatchDetailComponent } from './batch-detail/batch-detail.component';
import { BatchService } from './batch.service';

@NgModule({
  declarations: [
    AppComponent,
    BatchListComponent,
    BatchDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [BatchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
