import { Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {

@Output() public EventObj = new EventEmitter();


public SendEventFromButton()
{
  this.EventObj.emit("i am sending you Message As a child");
}


}
