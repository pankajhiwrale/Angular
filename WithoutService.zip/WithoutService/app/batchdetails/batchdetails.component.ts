import { Component } from '@angular/core';

@Component({
  selector: 'app-batchdetails',
  templateUrl: './batchdetails.component.html',
  styleUrls: ['./batchdetails.component.css']
})
export class BatchdetailsComponent {

  public Batches = [
    {"Name" : "PPA", "Fees": 9000, "Duration" : "8 Months"},
    {"Name" : "Angular", "Fees" : 18000, "Duration" : "4 Months"}
  ]

}
