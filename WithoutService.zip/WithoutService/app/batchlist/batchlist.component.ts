import { Component } from '@angular/core';

@Component({
  selector: 'app-batchlist',
  templateUrl: './batchlist.component.html',
  styleUrls: ['./batchlist.component.css']
})
export class BatchlistComponent {

  public Batches = [
    {"Name" : "PPA", "Fees": 9000, "Duration" : "8 Months"},
    {"Name" : "Angular", "Fees" : 18000, "Duration" : "4 Months"}
  ]

}
